#!/usr/bin/env node
// ASTIE DIESEL — Etapa 4: compila la app Android.
//
//   node scripts/android-build.mjs debug     → APK de prueba (firma de debug)
//   node scripts/android-build.mjs release   → APK firmado para distribuir directamente
//   node scripts/android-build.mjs aab       → bundle firmado para Google Play
//
// Hace: vite build --mode android → cap sync android → Gradle → copia el resultado a release/

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, mkdirSync, copyFileSync } from "node:fs";
import { join, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { ensureGradleWrapper, WRAPPER_HELP } from "./android-wrapper.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");
const androidDir = join(root, "android");
const isWin = process.platform === "win32";

const TARGETS = {
  debug:   { task: "assembleDebug",  out: "app/build/outputs/apk/debug/app-debug.apk",         signed: false },
  release: { task: "assembleRelease", out: "app/build/outputs/apk/release/app-release.apk",    signed: true  },
  aab:     { task: "bundleRelease",   out: "app/build/outputs/bundle/release/app-release.aab", signed: true  },
};

const kind = process.argv[2] || "debug";
const target = TARGETS[kind];
const fail = (m) => { console.error(`[build] ERROR: ${m}`); process.exit(1); };
if (!target) fail(`Tipo desconocido "${kind}". Usa: ${Object.keys(TARGETS).join(" | ")}`);
if (!existsSync(androidDir)) fail("No existe android/. Ejecuta primero: node scripts/android-setup.mjs");
if (target.signed && !existsSync(join(androidDir, "keystore.properties"))) {
  fail("Falta android/keystore.properties (ver README-etapa4.md, sección «Firma»). Sin firma el APK no se puede instalar.");
}

if (!existsSync(join(root, "node_modules", "@capacitor", "android", "package.json"))) {
  fail("Faltan las dependencias de Capacitor. Ejecuta primero: npm install");
}

function run(cmd, args, cwd = root) {
  console.log(`[build] > ${cmd} ${args.join(" ")}`);
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: isWin });
  if (r.status !== 0) fail(`falló: ${cmd} ${args.join(" ")}`);
}

// Mantener sincronizado el permiso de red con .env.android (si cambiaste la URL del backend)
run("node", [join("scripts", "android-setup.mjs"), "--patch-only"]);

const wrapper = ensureGradleWrapper(root);
if (!wrapper.ok) fail(`No encuentro gradlew ni pude crearlo (${wrapper.reason}). ${WRAPPER_HELP}`);

run("npx", ["vite", "build", "--mode", "android"]);
run("npx", ["cap", "sync", "android"]);

// En Windows gradlew.bat; en Linux/macOS "sh gradlew" evita depender del bit de ejecución.
if (isWin) run("gradlew.bat", [target.task], androidDir);
else run("sh", ["./gradlew", target.task], androidDir);

let outFile = join(androidDir, target.out);
// Sin firma, Gradle deja app-release-unsigned.apk
if (!existsSync(outFile) && kind === "release") {
  outFile = join(androidDir, "app/build/outputs/apk/release/app-release-unsigned.apk");
}
if (!existsSync(outFile)) fail(`No encuentro el resultado esperado: ${outFile}`);

const version = JSON.parse(readFileSync(join(root, "package.json"), "utf8")).version || "0.0.0";
mkdirSync(join(root, "release"), { recursive: true });
const dest = join(root, "release", `ASTIE-DIESEL-${version}-${kind}${extname(outFile)}`);
copyFileSync(outFile, dest);
console.log(`\n[build] Listo: ${dest}`);
if (kind === "debug") console.log("[build] Instalar en un dispositivo conectado:  adb install -r \"" + dest + "\"");
