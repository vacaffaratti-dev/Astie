// Capa de datos — Etapas 3-4: cliente HTTP + WebSocket hacia el backend propio (carpeta server/).
//
// Sustituye a src/api/db.js de la etapa 2 (localStorage) sin cambiar la API:
//   db.entities.Product.list(sort, limit, skip)
//   db.entities.Product.filter(query, sort, limit, skip)
//   db.entities.Product.get(id)
//   db.entities.Product.create(data)
//   db.entities.Product.update(id, data)
//   db.entities.Product.delete(id)
//   db.entities.Product.importRows(rows, { replace })
//   db.entities.Message.subscribe(callback) → unsubscribe()
//
// La URL del backend se toma de VITE_API_URL (ver .env / .env.production).
// Los headers de autenticación se guardan según el rol (ver storeFor más abajo; los pone session.jsx).

import { SCHEMA } from "./schema";

// ── Configuración ─────────────────────────────────────────────────────────────

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3001";
const WS_BASE  = API_BASE.replace(/^http/, "ws");

// ── Headers de autenticación ──────────────────────────────────────────────────
// session.jsx debe llamar a setAuthHeaders() al hacer login y clearAuthHeaders() al logout.

let authHeaders = {};

export function setAuthHeaders(headers) {
  authHeaders = { ...headers };
  bus.reset();
}

export function clearAuthHeaders() {
  authHeaders = {};
  bus.reset();
}

// Almacenamiento de la sesión (etapa 4, Android).
// El WebView de Android pierde sessionStorage cuando el sistema cierra la app, así que:
//   · cliente        → localStorage   (la sesión sobrevive al cierre de la app)
//   · admin/vendedor → sessionStorage (su token es la contraseña maestra: no se deja en disco)
// Para persistir también al personal, devuelve siempre localStorage aquí.
export function storeFor(role) {
  return role === "customer" ? localStorage : sessionStorage;
}

const AUTH_KEY = "astie_auth_headers";

// Recuperar headers guardados (para sobrevivir recargas y reinicios de la app)
try {
  const saved = localStorage.getItem(AUTH_KEY) ?? sessionStorage.getItem(AUTH_KEY);
  if (saved) authHeaders = JSON.parse(saved);
} catch { /* ignore */ }

export function persistAuthHeaders(headers) {
  authHeaders = { ...headers };
  try {
    const keep = storeFor(headers["x-astie-role"]);
    const other = keep === localStorage ? sessionStorage : localStorage;
    other.removeItem(AUTH_KEY);
    keep.setItem(AUTH_KEY, JSON.stringify(headers));
  } catch { /* ignore */ }
  bus.reset();
}

export function dropAuthHeaders() {
  authHeaders = {};
  try {
    localStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(AUTH_KEY);
  } catch { /* ignore */ }
  bus.reset();
}

// ── Fetch helper ──────────────────────────────────────────────────────────────

export async function apiFetch(method, path, body) {
  const headers = {
    "Content-Type": "application/json",
    ...authHeaders,
  };
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return data;
}

// ── WebSocket para suscripciones en tiempo real ───────────────────────────────
// El servidor exige autenticarse: el primer mensaje del socket lleva las credenciales de la sesión
// ({ type: "auth", role, token, id }) y solo entrega eventos de lo que ese rol puede ver.
// Sin sesión iniciada no se abre ninguna conexión; al iniciar o cerrar sesión se reconecta (reset()).

class RealtimeBus {
  constructor() {
    this._ws = null;
    this._listeners = {};   // { "entity:quoteId": [cb, ...] }
    this._subs = new Map(); // clave → mensaje de suscripción (se reenvía al reconectar)
    this._reconnectDelay = 1000;
    this._timer = null;
    this._rejected = false; // el servidor rechazó las credenciales (4401): no reintentar
    this._connect();
  }

  _credentials() {
    const role = authHeaders["x-astie-role"];
    if (!role) return null;
    return { type: "auth", role, token: authHeaders["x-astie-token"], id: authHeaders["x-astie-id"] };
  }

  _connect() {
    clearTimeout(this._timer);
    const auth = this._credentials();
    if (!auth || this._ws || this._rejected) return;

    let ws;
    try {
      ws = new WebSocket(`${WS_BASE}/ws`);
    } catch {
      return; // WebSocket no disponible (ej. SSR)
    }
    this._ws = ws;

    ws.onopen = () => {
      this._reconnectDelay = 1000;
      ws.send(JSON.stringify(auth));
      // Re-suscribir todo lo que había (el servidor procesa "auth" antes que las suscripciones)
      this._subs.forEach((msg) => ws.send(JSON.stringify(msg)));
    };

    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.type === "event") {
          const key = msg.event?.data?.quote_id
            ? `${msg.entity}:${msg.event.data.quote_id}`
            : msg.entity;
          // Notificar a suscriptores con quoteId específico y a los generales
          [...new Set([key, msg.entity])].forEach((k) => {
            (this._listeners[k] || []).forEach((cb) => {
              try { cb(msg.event); } catch { /* ignore */ }
            });
          });
        }
      } catch { /* ignore */ }
    };

    ws.onclose = (evt) => {
      if (this._ws !== ws) return; // socket ya reemplazado por reset()
      this._ws = null;
      if (evt.code === 4401) {
        // Credenciales rechazadas (p. ej. cambió la contraseña maestra): hace falta volver a iniciar sesión
        this._rejected = true;
        console.warn("[realtime] El servidor rechazó la sesión; inicia sesión de nuevo para recibir avisos en vivo.");
        return;
      }
      // Reconexión exponencial con tope en 30 s
      this._timer = setTimeout(() => {
        this._reconnectDelay = Math.min(this._reconnectDelay * 2, 30_000);
        this._connect();
      }, this._reconnectDelay);
    };
  }

  // Llamar cuando cambian las credenciales (login / logout): reconecta con la sesión nueva.
  reset() {
    clearTimeout(this._timer);
    this._rejected = false;
    this._reconnectDelay = 1000;
    const old = this._ws;
    this._ws = null;
    if (old) {
      old.onopen = old.onmessage = old.onclose = null;
      try { old.close(); } catch { /* ignore */ }
    }
    this._connect();
  }

  subscribe(entity, quoteId, callback) {
    const key = quoteId ? `${entity}:${quoteId}` : entity;
    (this._listeners[key] ||= []).push(callback);

    const msg = quoteId
      ? { type: "subscribe", entity, quoteId }
      : { type: "subscribe", entity };
    this._subs.set(key, msg);
    if (this._ws?.readyState === WebSocket.OPEN) {
      this._ws.send(JSON.stringify(msg));
    } else {
      this._connect(); // por si ya hay sesión y aún no había socket
    }

    return () => {
      this._listeners[key] = (this._listeners[key] || []).filter((cb) => cb !== callback);
      if (!this._listeners[key].length) {
        this._subs.delete(key);
        const unsub = { type: "unsubscribe", entity, ...(quoteId ? { quoteId } : {}) };
        if (this._ws?.readyState === WebSocket.OPEN) {
          this._ws.send(JSON.stringify(unsub));
        }
      }
    };
  }
}

// Instancia única del bus WebSocket (se crea al importar el módulo)
const bus = new RealtimeBus();

// ── Fábrica de entidades ──────────────────────────────────────────────────────

function createEntity(name) {
  const path = `/api/${name}`;

  return {
    list(sort, limit, skip) {
      const params = new URLSearchParams();
      if (sort)  params.set("sort",  sort);
      if (limit) params.set("limit", limit);
      if (skip)  params.set("skip",  skip);
      const qs = params.toString();
      return apiFetch("GET", `${path}${qs ? "?" + qs : ""}`);
    },

    filter(filters, sort, limit, skip) {
      const params = new URLSearchParams();
      if (sort)  params.set("sort",  sort);
      if (limit) params.set("limit", limit);
      if (skip)  params.set("skip",  skip);
      // Filtros simples → ?campo=valor · con operadores → ?campo[$gt]=5 (el servidor los interpreta con qs)
      for (const [k, v] of Object.entries(filters || {})) {
        if (v && typeof v === "object" && !Array.isArray(v)) {
          for (const [op, arg] of Object.entries(v)) {
            if (Array.isArray(arg)) arg.forEach((a) => params.append(`${k}[${op}][]`, a));
            else params.set(`${k}[${op}]`, arg);
          }
        } else {
          params.set(k, v);
        }
      }
      const qs = params.toString();
      return apiFetch("GET", `${path}${qs ? "?" + qs : ""}`);
    },

    get(id) {
      return apiFetch("GET", `${path}/${id}`);
    },

    create(data) {
      return apiFetch("POST", path, data);
    },

    update(id, data) {
      return apiFetch("PUT", `${path}/${id}`, data);
    },

    delete(id) {
      return apiFetch("DELETE", `${path}/${id}`);
    },

    importRows(rows, { replace = false } = {}) {
      return apiFetch("POST", `${path}/import${replace ? "?replace=1" : ""}`, { rows, replace });
    },

    // Suscripción en tiempo real.
    // quoteId es opcional: si se pasa, solo notifica eventos de ese quote.
    subscribe(callbackOrQuoteId, maybeCallback) {
      // Sobrecarga: subscribe(cb) o subscribe(quoteId, cb)
      const [quoteId, callback] =
        typeof callbackOrQuoteId === "string"
          ? [callbackOrQuoteId, maybeCallback]
          : [null, callbackOrQuoteId];
      return bus.subscribe(name, quoteId, callback);
    },
  };
}

// ── Exportar ──────────────────────────────────────────────────────────────────

export const db = {
  entities: Object.fromEntries(Object.keys(SCHEMA).map((name) => [name, createEntity(name)])),
};
