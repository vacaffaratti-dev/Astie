// Esquema de datos de la app (antes vivía en la carpeta "base44/entities").
// Se usa para: valores por defecto, campos obligatorios y conversión de tipos al importar datos.
// (id, created_date y updated_date los gestiona la capa de datos.)

export const SCHEMA = {
  AppSettings: {
    defaults: {"store_name": "ASTIE DIESEL"},
    required: [],
    fields: {"store_name": "string", "admin_password_hash": "string", "seller_password_hash": "string"},
  },
  Category: {
    defaults: {"order": 0},
    required: ["name"],
    fields: {"name": "string", "description": "string", "image_url": "string", "order": "number"},
  },
  Customer: {
    defaults: {},
    required: ["full_name", "last_name", "phone"],
    fields: {"full_name": "string", "last_name": "string", "phone": "string", "email": "string", "address": "string"},
  },
  Message: {
    defaults: {"is_quote": false},
    required: ["quote_id", "sender_type", "text"],
    fields: {"quote_id": "string", "sender_type": "string", "sender_id": "string", "sender_name": "string", "text": "string", "is_quote": "boolean", "amount": "number"},
  },
  Product: {
    defaults: {"stock": 0, "active": true},
    required: ["name", "category_id"],
    fields: {"name": "string", "description": "string", "image_url": "string", "stock": "number", "reference_price": "number", "category_id": "string", "subcategory_id": "string", "active": "boolean"},
  },
  Quote: {
    defaults: {"status": "pending"},
    required: ["customer_id", "customer_name"],
    fields: {"customer_id": "string", "customer_name": "string", "customer_phone": "string", "customer_email": "string", "seller_id": "string", "seller_name": "string", "status": "string", "items": "array", "agreed_total": "number", "comment": "string", "closed_date": "string"},
  },
  Seller: {
    defaults: {"status": "active", "chats_responded": 0},
    required: ["name"],
    fields: {"name": "string", "email": "string", "phone": "string", "status": "string", "last_access": "string", "chats_responded": "number"},
  },
  Subcategory: {
    defaults: {"order": 0},
    required: ["name", "category_id"],
    fields: {"name": "string", "category_id": "string", "order": "number"},
  },
};

// Entidades que se pueden respaldar/importar (AppSettings queda fuera: contiene las contraseñas).
export const DATA_ENTITIES = Object.keys(SCHEMA).filter((n) => n !== "AppSettings");
