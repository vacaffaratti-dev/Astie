import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter, HashRouter, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import { SessionProvider } from '@/lib/session';
import { CartProvider } from '@/lib/cart';
import AppShell from '@/components/AppShell';
import RoleGuard from '@/components/RoleGuard';
import Entry from '@/pages/Entry';
import CustomerRegister from '@/pages/CustomerRegister';
import Home from '@/pages/Home';
import ProductDetail from '@/pages/ProductDetail';
import Cart from '@/pages/Cart';
import Chat from '@/pages/Chat';
import MyQuotes from '@/pages/MyQuotes';
import Profile from '@/pages/Profile';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminCategories from '@/pages/admin/AdminCategories';
import AdminProducts from '@/pages/admin/AdminProducts';
import AdminSellers from '@/pages/admin/AdminSellers';
import AdminCustomers from '@/pages/admin/AdminCustomers';
import AdminQuotes from '@/pages/admin/AdminQuotes';
import AdminSettings from '@/pages/admin/AdminSettings';
import SellerDashboard from '@/pages/seller/SellerDashboard';
import SellerQuotes from '@/pages/seller/SellerQuotes';
import SellerHistory from '@/pages/seller/SellerHistory';

// Web y Capacitor usan rutas normales. Las herramientas que empaquetan un WebView propio sirven la app
// desde una ruta tipo /web/index.html, donde BrowserRouter no encuentra ninguna pantalla:
// para esas se compila con `npm run build:webview` (VITE_ROUTER=hash → rutas con #).
const Router = import.meta.env.VITE_ROUTER === "hash" ? HashRouter : BrowserRouter;

const AppRoutes = () => {
  return (
    <SessionProvider>
      <CartProvider>
        <Routes>
          <Route path="/" element={<Entry />} />
          <Route path="/register" element={<CustomerRegister />} />

          {/* Customer routes */}
          <Route element={<RoleGuard roles={["customer"]} />}>
            <Route element={<AppShell />}>
              <Route path="/catalog" element={<Home />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/my-quotes" element={<MyQuotes />} />
              <Route path="/profile" element={<Profile />} />
            </Route>
          </Route>
          <Route path="/chat/:id" element={<Chat />} />

          {/* Admin routes */}
          <Route element={<RoleGuard roles={["admin"]} />}>
            <Route element={<AppShell />}>
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/categories" element={<AdminCategories />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/sellers" element={<AdminSellers />} />
              <Route path="/admin/customers" element={<AdminCustomers />} />
              <Route path="/admin/quotes" element={<AdminQuotes />} />
              <Route path="/admin/settings" element={<AdminSettings />} />
            </Route>
          </Route>
          <Route path="/admin/chat/:id" element={<Chat />} />

          {/* Seller routes */}
          <Route element={<RoleGuard roles={["seller"]} />}>
            <Route element={<AppShell />}>
              <Route path="/seller" element={<SellerDashboard />} />
              <Route path="/seller/quotes" element={<SellerQuotes />} />
              <Route path="/seller/history" element={<SellerHistory />} />
            </Route>
          </Route>
          <Route path="/seller/chat/:id" element={<Chat />} />

          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </CartProvider>
    </SessionProvider>
  );
};


function App() {

  return (
    <QueryClientProvider client={queryClientInstance}>
      <Router>
        <ScrollToTop />
        <AppRoutes />
      </Router>
      <Toaster />
    </QueryClientProvider>
  )
}

export default App