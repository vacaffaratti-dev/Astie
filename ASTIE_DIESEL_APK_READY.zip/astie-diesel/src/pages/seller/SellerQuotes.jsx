import React from "react";
import QuoteList from "@/pages/admin/QuoteList";

export default function SellerQuotes() {
  return <QuoteList title="Cotizaciones pendientes" basePath="/seller/chat" />;
}