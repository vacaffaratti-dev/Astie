# Backend (carpeta `server/`)

Servidor propio en **Node.js + SQLite + WebSocket** que guarda los datos compartidos y da el chat en tiempo real.

| Capa | Tecnología |
|---|---|
| Servidor | Express 4 |
| Base de datos | SQLite (better-sqlite3), archivo `server/data/astie.db` (se crea solo) |
| Tiempo real | WebSocket (ws) en `/ws`, mismo puerto que HTTP |
| Auth | Contraseñas maestras con PBKDF2 · headers `x-astie-*` |

---

## Arranque

Desde la raíz del proyecto:

```bash
npm run server:install      # una vez (better-sqlite3 se compila/descarga según tu sistema)
npm run server:dev          # desarrollo, recarga automática
npm run server              # producción
curl http://localhost:3001/health
```

Requiere Node 18 o superior.

## Variables de entorno

| Variable | Por defecto | Descripción |
|---|---|---|
| `PORT` | `3001` | Puerto HTTP/WS |
| `DB_PATH` | `server/data/astie.db` | Archivo SQLite |
| `ORIGIN` | `*` | Origen(es) CORS permitidos, separados por comas. La app Android se sirve desde `http://localhost`; ej.: `ORIGIN=https://tienda.com,http://localhost` |

---

## API REST

### Autenticación

Cada petición lleva sus credenciales en headers:

| Header | Valor | Roles |
|---|---|---|
| `x-astie-role` | `admin` / `seller` / `customer` | todos |
| `x-astie-token` | contraseña maestra | admin, seller |
| `x-astie-id` | id del cliente | customer |

```
GET  /api/auth/setup-done      → { done: bool }
POST /api/auth/setup           → { admin, seller, storeName }   (solo mientras no esté configurada)
POST /api/auth/verify          → { role, password }
POST /api/auth/customer        → { full_name, last_name, phone, email?, address? }  (busca por teléfono o crea)
POST /api/auth/change-password → { role, newPassword }          (solo admin)
```

### Entidades

`AppSettings`, `Category`, `Subcategory`, `Product`, `Seller`, `Customer`, `Quote`, `Message`.

```
GET    /api/:entity              → lista (?sort=-campo&limit=&skip=&campo=valor)
GET    /api/:entity/:id
POST   /api/:entity
PUT    /api/:entity/:id
DELETE /api/:entity/:id
POST   /api/:entity/import       → { rows, replace }   (solo admin)
```

Filtros: `?campo=valor` (los booleanos se envían como `true`/`false`) o con operadores
`?campo[$gt]=5` (`$eq $ne $gt $gte $lt $lte $in $nin`). Los nombres de campo y de orden solo pueden ser
identificadores simples (`[A-Za-z0-9_]`); cualquier otra cosa responde 400.

### Permisos

Según el rol (`src/access.js`; las mismas reglas valen para la API REST y el WebSocket):

| Entidad | admin | vendedor | cliente |
|---|---|---|---|
| Category, Subcategory, Product | leer y escribir | leer | leer |
| Quote | todo | leer y escribir | **solo las suyas**: leer y crear (siempre quedan `pending`; el presupuesto, el vendedor y el cierre son del personal) |
| Message | todo | leer y escribir | **solo los de sus cotizaciones**: leer y escribir (siempre como cliente y nunca como presupuesto) |
| Customer | todo | leer y escribir | **solo su perfil**: leer y editar |
| Seller | todo | leer | — |
| AppSettings | todo | — | — |

Para un cliente, lo ajeno «no existe»: un listado solo devuelve lo suyo (aunque pida otro `customer_id`) y un `GET` por id de algo ajeno responde 404.
Escribir en algo ajeno, o modificar/borrar cotizaciones o mensajes, responde 403.

### Respaldo

```
GET  /api/backup                   → exporta todos los datos          [admin]
POST /api/backup/import            → importa un respaldo              [admin]
POST /api/backup/import?replace=1  → reimporta limpiando primero      [admin]
```

La pantalla **Admin → Configuración → Datos y respaldo** usa las rutas de entidades (`list` / `import`), no estas.

---

## WebSocket (chat en tiempo real)

`ws://host:3001/ws` (o `wss://` detrás de HTTPS). El frontend lo maneja en `src/api/db.js`: se conecta al iniciar sesión,
se reconecta solo y se cierra al cerrar sesión.

**Hay que autenticarse primero.** Los navegadores no pueden mandar headers en un WebSocket, así que las credenciales
van en el primer mensaje (las mismas de la API REST):

```json
{ "type": "auth", "role": "customer", "id": "…" }
{ "type": "auth", "role": "seller", "token": "contraseña maestra" }
```

Después:

```json
{ "type": "subscribe", "entity": "Message", "quoteId": "abc123" }
{ "type": "unsubscribe", "entity": "Message", "quoteId": "abc123" }
{ "type": "ping" }
```

Respuestas: `{ "type": "auth_ok" }`, `{ "type": "event", "entity": "Message", "event": { "id", "type": "create|update|delete", "data": {…} } }`,
`{ "type": "pong" }` y `{ "type": "error", "message": "…" }`.

- Sin `auth` válido en 10 s, o con credenciales incorrectas, el servidor cierra con el código **4401**.
- Solo se puede suscribir a entidades que el rol puede leer (`AppSettings`, por ejemplo, solo el admin).
- Un cliente solo recibe los eventos de sus propias cotizaciones, mensajes y perfil.

---

## Estructura

```
server/
├── src/
│   ├── db/database.js       ← acceso a SQLite; misma API que db.js del frontend
│   ├── db/schema.js         ← DDL + mapa de entidades
│   ├── middleware/auth.js   ← verificación de headers + PBKDF2
│   ├── routes/              ← auth.js · backup.js · entities.js (CRUD genérico y permisos)
│   ├── events.js            ← bus de eventos + servidor WebSocket
│   └── server.js            ← arranque
└── package.json
```

## Migrar datos existentes

Lo más simple: en la app, **Admin → Configuración → Importar** (acepta el respaldo `.json` de la app o los `.csv` de Base44,
ver `MIGRAR_DATOS_BASE44.md`). Por línea de comandos:

```bash
curl -X POST http://localhost:3001/api/backup/import \
  -H "Content-Type: application/json" \
  -H "x-astie-role: admin" -H "x-astie-token: TU_CONTRASEÑA" \
  --data-binary @respaldo.json
```

---

## Limitaciones conocidas

- **`/api/auth/setup` está abierto hasta que se configura la app.** Haz la configuración inicial apenas despliegues el servidor.
- **Los clientes se identifican solo por teléfono** (sin contraseña): quien conozca el teléfono de un cliente puede entrar como él y ver sus cotizaciones y chats. La API ya no deja ver lo de otros clientes, pero esta identificación sigue siendo débil.
- El token del personal es una sesión temporal y viaja en cada petición: usa HTTPS fuera de una red de confianza.
- Las credenciales del WebSocket se verifican al conectar: si el admin cambia una contraseña maestra, los sockets ya abiertos siguen funcionando hasta que se reconecten.
- No hay límite de intentos para adivinar las contraseñas maestras.
