# Traer tus datos desde Base44

Solo hace falta si la app en Base44 ya tiene datos reales (productos, clientes, cotizaciones…).
Si empiezas de cero, salta esta guía.

## 1. Exportar desde Base44

En el panel de tu app en Base44, en la sección de datos, cada entidad (Category, Subcategory,
Product, Customer, Seller, Quote, Message) se puede exportar a **CSV**. Exporta las que uses.
(El nombre exacto del botón puede variar según la versión de Base44.)

Deja el nombre de cada archivo con el nombre de la entidad (por ejemplo `Product.csv`,
`Product_export.csv`): la app lo detecta sola. Si no lo reconoce, te deja elegir a qué
datos corresponde cada archivo.

## 2. Importar en la app

1. Entra como administrador → **Configuración** → **Datos y respaldo**.
2. **Elegir archivos a importar** y selecciona todos los CSV a la vez.
3. Revisa que cada archivo tenga asignado su tipo de datos y pulsa **Importar**.

- Se conservan los `id` y las fechas originales, así que las relaciones (producto ↔ categoría,
  mensajes ↔ cotización) siguen funcionando.
- **Combinar** agrega lo nuevo y actualiza lo existente; **Reemplazar** vacía primero esas tablas.
- Las contraseñas no se importan: se crean en la configuración inicial de la app.

## 3. Imágenes (importante)

Las imágenes subidas a Base44 siguen alojadas allí: si cierras tu cuenta, dejarán de verse.
Para llevarlas contigo:

```bash
# 1) En la app: Configuración → Descargar respaldo (.json)
# 2) En la carpeta del proyecto (necesitas Node 18+ e internet):
node scripts/download-images.mjs astie-diesel-respaldo-2026-09-19.json
# 3) En la app: Configuración → Importar → elige el archivo ...imagenes-locales.json → Combinar
```

El script guarda las imágenes en `public/images/` y crea un respaldo nuevo donde `image_url`
apunta a `/images/…`. Esas imágenes viajan dentro de la app (y del APK).

- Por defecto solo descarga URLs cuyo host contenga `base44` o `wixstatic`.
  Usa `--all` para descargar todas las URLs http(s), o `--hosts host1,host2` para elegir.
- Si alguna imagen falla, el script la lista y deja esa URL sin cambios.
- Tras descargar, **vuelve a compilar** (`npm run build`) para que las imágenes queden incluidas.
