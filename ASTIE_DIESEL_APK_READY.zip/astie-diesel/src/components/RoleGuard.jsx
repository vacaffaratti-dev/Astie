import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useSession } from "@/lib/session";

export default function RoleGuard({ roles }) {
  const { session, loading } = useSession();
  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;
  if (!session || !roles.includes(session.role)) return <Navigate to="/" replace />;
  return <Outlet />;
}