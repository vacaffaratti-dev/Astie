#!/usr/bin/env node
// Descarga las imágenes de productos/categorías que siguen alojadas en Base44 (u otros hosts)
// a public/images/ y reescribe image_url para que apunte a la copia local (/images/...).
//
// Uso:
//   node scripts/download-images.mjs respaldo.json
//   node scripts/download-images.mjs respaldo.json --all             # todas las URLs http(s), no solo Base44
//   node scripts/download-images.mjs respaldo.json --hosts base44,miservidor.com
//   node scripts/download-images.mjs respaldo.json --out public/images
//
// Entrada: el respaldo .json que descarga la app (Configuración → Descargar respaldo).
// Salida:  <respaldo>.imagenes-locales.json  → impórtalo en la app (Configuración → Importar).

import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile, access } from "node:fs/promises";
import path from "node:path";

const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const option = (name, fallback) => {
  const i = args.indexOf(name);
  return i !== -1 && args[i + 1] ? args[i + 1] : fallback;
};

const input = args.find((a) => !a.startsWith("--") && a !== option("--out") && a !== option("--hosts"));
if (!input) {
  console.error("Uso: node scripts/download-images.mjs <respaldo.json> [--out public/images] [--all] [--hosts base44,wixstatic]");
  process.exit(2);
}

const outDir = option("--out", "public/images");
const publicPrefix = "/images/";
const all = flag("--all");
const hosts = option("--hosts", "base44,wixstatic").split(",").map((h) => h.trim().toLowerCase()).filter(Boolean);
const ENTITIES = ["Product", "Category"];
const CONCURRENCY = 4;

const EXT_BY_TYPE = {
  "image/jpeg": ".jpg", "image/jpg": ".jpg", "image/png": ".png", "image/webp": ".webp",
  "image/gif": ".gif", "image/svg+xml": ".svg", "image/avif": ".avif",
};

const shouldDownload = (url) => {
  try {
    const u = new URL(url);
    if (!["http:", "https:"].includes(u.protocol)) return false;
    return all || hosts.some((h) => u.hostname.toLowerCase().includes(h));
  } catch {
    return false;
  }
};

const exists = (p) => access(p).then(() => true, () => false);

async function download(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(30000), redirect: "follow" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const type = (res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
  if (!type.startsWith("image/")) throw new Error(`no es una imagen (${type || "sin tipo"})`);
  const urlExt = path.extname(new URL(url).pathname).toLowerCase();
  const ext = EXT_BY_TYPE[type] || (/^\.(jpe?g|png|webp|gif|svg|avif)$/.test(urlExt) ? urlExt : ".jpg");
  return { buffer: Buffer.from(await res.arrayBuffer()), ext };
}

const backup = JSON.parse(await readFile(input, "utf8"));
if (!backup?.data || typeof backup.data !== "object") {
  console.error("El archivo no parece un respaldo de ASTIE DIESEL (falta la clave \"data\").");
  process.exit(2);
}

// URL -> nombre de archivo local (misma URL = mismo archivo)
const urls = new Map();
for (const entity of ENTITIES) {
  for (const row of backup.data[entity] || []) {
    if (row.image_url && shouldDownload(row.image_url)) urls.set(row.image_url, null);
  }
}

await mkdir(outDir, { recursive: true });
const failures = [];
const queue = [...urls.keys()];
let done = 0;

async function worker() {
  while (queue.length) {
    const url = queue.shift();
    const hash = createHash("sha1").update(url).digest("hex").slice(0, 12);
    try {
      // Si ya se descargó antes (misma URL), se reutiliza.
      const existing = ["jpg", "png", "webp", "gif", "svg", "avif"].map((e) => `img-${hash}.${e}`);
      let file = null;
      for (const name of existing) if (await exists(path.join(outDir, name))) { file = name; break; }
      if (!file) {
        const { buffer, ext } = await download(url);
        file = `img-${hash}${ext}`;
        await writeFile(path.join(outDir, file), buffer);
      }
      urls.set(url, file);
    } catch (err) {
      failures.push({ url, error: err.message });
    }
    process.stdout.write(`\r  ${++done}/${urls.size} imágenes procesadas`);
  }
}

console.log(`Imágenes a descargar: ${urls.size}${all ? " (todas las URLs)" : ` (hosts que contienen: ${hosts.join(", ")})`}`);
await Promise.all(Array.from({ length: CONCURRENCY }, worker));
if (urls.size) console.log("");

let rewritten = 0;
for (const entity of ENTITIES) {
  for (const row of backup.data[entity] || []) {
    const file = urls.get(row.image_url);
    if (file) {
      row.image_url = publicPrefix + file;
      rewritten++;
    }
  }
}

const output = input.replace(/\.json$/i, "") + ".imagenes-locales.json";
await writeFile(output, JSON.stringify(backup, null, 2));

console.log(`Listo: ${rewritten} registros ahora apuntan a ${publicPrefix}… (archivos en ${outDir}/)`);
console.log(`Respaldo actualizado: ${output}`);
if (failures.length) {
  console.log(`\nNo se pudieron descargar ${failures.length} imágenes (se dejaron sin cambios):`);
  for (const f of failures) console.log(`  - ${f.url} → ${f.error}`);
  process.exitCode = 1;
}
