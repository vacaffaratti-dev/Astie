// ASTIE DIESEL — Etapa 4: asegura que android/ tenga el Gradle Wrapper (gradlew, gradlew.bat y gradle-wrapper.jar).
//
// El .jar es binario y no viaja en el proyecto; lo trae el CLI de Capacitor dentro de su plantilla oficial
// (node_modules/@capacitor/cli/assets/android-template.tar.gz). Se extrae con `tar` (incluido en
// Windows 10+, macOS y Linux) y solo se copian esos tres archivos: el resto de android/ no se toca.

import { spawnSync } from "node:child_process";
import {
  existsSync, mkdirSync, copyFileSync, readdirSync, statSync, chmodSync, mkdtempSync, rmSync,
} from "node:fs";
import { join, dirname, basename } from "node:path";
import { tmpdir } from "node:os";

// Devuelve { ok, copied?, reason? }.  reason: "no-archive" | "tar" | "incomplete"
export function ensureGradleWrapper(root) {
  const androidDir = join(root, "android");
  const targets = {
    "gradle-wrapper.jar": join(androidDir, "gradle", "wrapper", "gradle-wrapper.jar"),
    "gradlew": join(androidDir, "gradlew"),
    "gradlew.bat": join(androidDir, "gradlew.bat"),
  };
  if (Object.values(targets).every((p) => existsSync(p))) return { ok: true, copied: false };

  const archive = join(root, "node_modules", "@capacitor", "cli", "assets", "android-template.tar.gz");
  if (!existsSync(archive)) return { ok: false, reason: "no-archive" };

  const tmp = mkdtempSync(join(tmpdir(), "astie-template-"));
  try {
    // cwd + nombre relativo: evita que `tar` interprete "C:" de una ruta de Windows como un equipo remoto
    const r = spawnSync("tar", ["-xzf", basename(archive), "-C", tmp], { cwd: dirname(archive), stdio: "pipe" });
    if (r.error || r.status !== 0) return { ok: false, reason: "tar" };

    const found = {};
    const walk = (dir) => {
      for (const name of readdirSync(dir)) {
        const p = join(dir, name);
        if (statSync(p).isDirectory()) walk(p);
        else if (name in targets && !found[name]) found[name] = p;
      }
    };
    walk(tmp);
    if (Object.keys(targets).some((n) => !found[n])) return { ok: false, reason: "incomplete" };

    for (const [name, dest] of Object.entries(targets)) {
      mkdirSync(dirname(dest), { recursive: true });
      copyFileSync(found[name], dest);
    }
    try { chmodSync(targets.gradlew, 0o755); } catch { /* en Windows no aplica */ }
    return { ok: true, copied: true };
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
}

export const WRAPPER_HELP =
  "Abre la carpeta android/ en Android Studio y, en el panel Gradle, ejecuta la tarea «wrapper» " +
  "(Tasks → build setup → wrapper); genera gradlew y gradle-wrapper.jar. También sirve `gradle wrapper` si tienes Gradle instalado.";
