# ASTIE DIESEL

Plataforma de compras y cotizaciones: catálogo, carrito, cotizaciones y chat en tiempo real entre clientes,
vendedores y administrador. Proyecto unificado de las etapas 1 a 4: app web (React + Vite + Tailwind),
backend propio (Node + SQLite + WebSocket) y empaquetado Android (Capacitor + Gradle). Ya **no depende de Base44**.

```
astie-diesel/
├── src/                     frontend React
├── server/                  backend Express + SQLite + WebSocket
├── android/                 proyecto Android (Gradle + Capacitor 8) ya completo
├── capacitor.config.json    ┐
├── .env.android             │  empaquetado Android
├── android-kit/  scripts/   ┘
├── expo/                    App.js para probar la web en Expo Go
├── deploy/Caddyfile         HTTPS para el servidor
└── docs/                    BACKEND.md · ANDROID.md · MIGRAR_DATOS_BASE44.md
```

## Puesta en marcha (desarrollo)

```bash
npm install                  # frontend
npm run server:install       # backend (una vez)

npm run server:dev           # terminal 1 → http://localhost:3001/health
cp .env.example .env         # opcional: VITE_API_URL ya vale http://localhost:3001 por defecto
npm run dev                  # terminal 2 → app en http://localhost:5173
```

La primera vez, entra como **Administrador**: la app pide crear las contraseñas maestras (admin y vendedores).
Los datos quedan en `server/data/astie.db`, compartidos por todos los dispositivos.

## Producción

- **Servidor:** `npm run server` (variables `PORT`, `DB_PATH`, `ORIGIN` en [`docs/BACKEND.md`](docs/BACKEND.md)).
  Con dominio, `deploy/Caddyfile` da HTTPS y `wss://`.
- **Web:** pon la URL del servidor en `.env.production` y ejecuta `npm run build` (carpeta `dist/`).
- **Expo Go (pruebas en el celular):** [`expo/README.md`](expo/README.md).
- **Android:** [`docs/ANDROID.md`](docs/ANDROID.md). Resumen:
  ```bash
  # 1) URL del backend en .env.android
  npm install
  npm run android:debug              # compila la web, sincroniza android/ y genera el APK en release/
  ```

## Estado de la migración

| Etapa | Contenido | Estado |
|------|-----------|--------|
| 1 | Reparar estructura, quitar SDK/plugin de Base44, capa de datos propia | ✅ |
| 2 | Respaldo/importación (incl. Base44), imágenes propias, contraseñas protegidas | ✅ |
| 3 | Backend propio (Node + SQLite) con datos compartidos y chat en tiempo real | ✅ |
| 4 | Empaquetado Android (Capacitor + Gradle) apuntando al backend | ✅ (sin compilar aún, ver más abajo) |

## Qué cambió en cada etapa

**Etapa 1.** Nombres de archivo corregidos (`input,jsx`, `iamge-helpers.js`, `sellers/`…); eliminados `@base44/sdk`,
el plugin de Vite y las pantallas de login de Base44; alias `@` → `src` en `vite.config.js`; `ui/image.jsx` sin
dependencias externas; favicon y `manifest.json` propios.

**Etapa 2.** Respaldo e importación de datos (Admin → Configuración → *Datos y respaldo*; `.json` y `.csv`, incluidos los de
Base44: [`docs/MIGRAR_DATOS_BASE44.md`](docs/MIGRAR_DATOS_BASE44.md)); `scripts/download-images.mjs` baja las imágenes de Base44 a
`public/images/`; sin contraseña por defecto en el código.

**Etapa 3.** Backend en `server/` (ver [`docs/BACKEND.md`](docs/BACKEND.md)); `src/api/db.js` pasó a hablar HTTP + WebSocket con la
misma API de antes; las contraseñas se guardan y verifican en el servidor.

**Etapa 4.** Kit de empaquetado Android; sesión adaptada al WebView (cliente persistente, personal solo por sesión).

## Ajustes hechos al unificar las etapas

Al juntar las piezas aparecieron incompatibilidades entre la etapa 2 (frontend) y la 3 (backend), corregidas así:

- **`src/lib/settingsService.js` reescrito:** ya no calcula hashes en el navegador ni lee `AppSettings` (el servidor solo se lo
  permite al admin, así que la configuración inicial y el cambio de contraseñas no funcionaban). Ahora usa `/api/auth/*`.
- **`src/pages/CustomerRegister.jsx`:** usa `loginCustomer(form)`; el servidor busca al cliente por teléfono o lo crea. Antes
  intentaba leer/crear el cliente sin sesión y el servidor lo rechazaba.
- **`server/src/db/database.js`:**
  - los filtros booleanos (`?active=true`, que usa el catálogo) no coincidían con los 0/1 de SQLite y devolvían **cero productos**;
  - los nombres de campo y de orden llegaban sin validar al SQL (**inyección SQL**); ahora solo se aceptan identificadores simples.
- **`src/api/db.js`:** los filtros con operadores (`$gt`, `$in`…) hacían un GET con body, que el navegador rechaza; ahora
  viajan en la URL. Exporta `apiFetch` para `settingsService`.
- **`server/src/server.js`:** `ORIGIN` acepta varios orígenes separados por comas.
- **Seguridad del tiempo real y de la API (`server/src/access.js`, `events.js`):** el WebSocket ahora exige autenticarse y solo entrega
  eventos de lo que el rol puede leer (antes cualquiera podía suscribirse, incluso a `AppSettings`, que lleva los hashes de las contraseñas).
  Un cliente solo ve y modifica lo suyo: sus cotizaciones, los mensajes de ellas y su perfil; antes la API le devolvía todas las cotizaciones y
  mensajes, y le dejaba editar o borrar los ajenos y hacerse pasar por el vendedor. Como efecto, la pantalla de Perfil del cliente ya puede
  cargar sus datos (antes el servidor se los negaba).
- **`server/src/db/database.js`:** `create` y `update` devolvían `items: []` (en la respuesta y en los eventos) aunque se guardaran bien.
- **`src/api/db.js`:** el bus del WebSocket se autentica y reconecta al iniciar/cerrar sesión, y ya no llama dos veces a los suscriptores de
  eventos sin `quote_id`. `Chat.jsx` muestra «Cotización no encontrada» en vez de un spinner infinito si la cotización no existe o no es suya.
- El backend pasó de `astie-backend/` a **`server/`** (el `.gitignore` de la etapa 2 ya lo esperaba ahí); `DataBackup` dice
  «servidor» en vez de «este dispositivo»; `package.json` pasa a 2.0.0 con los scripts `server*` y `android*`; `.gitignore` versiona
  `.env.example` e ignora `release/`.

## Limitaciones conocidas

- Pendientes del backend (detalle en [`docs/BACKEND.md`](docs/BACKEND.md)): `/api/auth/setup` está abierto hasta que se configura la app; los
  clientes se identifican solo por teléfono (sin contraseña); no hay límite de intentos para las contraseñas maestras.
- Por `http` la contraseña maestra viaja sin cifrar: usa HTTPS fuera de una red de confianza.
- Las imágenes se indican por URL o desde `public/images/`; subir fotos desde la app no está implementado.
- El empaquetado Android se armó sin poder ejecutar Gradle en el entorno de desarrollo: el primer build puede pedir ajustes.

## Icono Android

El icono de la aplicación usa el logotipo proporcionado `YPF agro` como imagen de launcher, preparado en las densidades Android correspondientes.
