import React, { useState, useEffect } from "react";
import { getCategories, createCategory, updateCategory, deleteCategory, getSubcategories, createSubcategory, deleteSubcategory } from "@/lib/categoryService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ChevronDown, Tags } from "lucide-react";

export default function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [subcats, setSubcats] = useState({});
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", description: "", image_url: "" });
  const [open, setOpen] = useState(false);
  const [subForm, setSubForm] = useState({});
  const [subOpen, setSubOpen] = useState({});

  const load = async () => {
    const cats = await getCategories();
    setCategories(cats);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const loadSubs = async (catId) => {
    const subs = await getSubcategories(catId);
    setSubcats({ ...subcats, [catId]: subs });
  };

  const toggle = (catId) => {
    setExpanded({ ...expanded, [catId]: !expanded[catId] });
    if (!expanded[catId]) loadSubs(catId);
  };

  const save = async (e) => {
    e.preventDefault();
    if (editing) {
      await updateCategory(editing, form);
    } else {
      await createCategory({ ...form, order: categories.length + 1 });
    }
    setForm({ name: "", description: "", image_url: "" });
    setEditing(null);
    setOpen(false);
    load();
  };

  const edit = (c) => {
    setEditing(c.id);
    setForm({ name: c.name, description: c.description || "", image_url: c.image_url || "" });
    setOpen(true);
  };

  const remove = async (c) => {
    if (!confirm(`¿Eliminar la categoría "${c.name}"?`)) return;
    await deleteCategory(c.id);
    load();
  };

  const addSub = async (catId) => {
    const name = subForm[catId];
    if (!name) return;
    await createSubcategory({ name, category_id: catId, order: (subcats[catId]?.length || 0) + 1 });
    setSubForm({ ...subForm, [catId]: "" });
    setSubOpen({ ...subOpen, [catId]: false });
    loadSubs(catId);
  };

  const removeSub = async (catId, subId) => {
    await deleteSubcategory(subId);
    loadSubs(catId);
  };

  if (loading) return <div className="p-10 flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;

  return (
    <div className="p-6 lg:p-8 max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-semibold">Categorías</h1>
          <p className="text-stone-500 text-sm">Gestiona categorías y subcategorías</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => { setEditing(null); setForm({ name: "", description: "", image_url: "" }); }}><Plus className="w-4 h-4 mr-1" /> Nueva</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? "Editar categoría" : "Nueva categoría"}</DialogTitle></DialogHeader>
            <form onSubmit={save} className="space-y-3">
              <div><Label>Nombre</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
              <div><Label>Descripción</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
              <div><Label>URL de imagen</Label><Input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} /></div>
              <Button type="submit" className="w-full">Guardar</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {categories.map((c) => (
          <div key={c.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
            <div className="flex items-center gap-2 p-3">
              <button onClick={() => toggle(c.id)} className="p-1 hover:bg-stone-100 rounded">
                <ChevronDown className={`w-4 h-4 transition-transform ${expanded[c.id] ? "" : "-rotate-90"}`} />
              </button>
              <Tags className="w-4 h-4 text-emerald-700" />
              <div className="flex-1">
                <div className="font-medium text-sm">{c.name}</div>
                {c.description && <div className="text-xs text-stone-500">{c.description}</div>}
              </div>
              <button onClick={() => edit(c)} className="p-1.5 text-stone-400 hover:text-stone-900"><Pencil className="w-4 h-4" /></button>
              <button onClick={() => remove(c)} className="p-1.5 text-stone-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
            </div>
            {expanded[c.id] && (
              <div className="border-t border-stone-100 px-3 py-2 bg-white">
                <div className="text-xs uppercase tracking-wider text-stone-400 mb-2 mt-1">Subcategorías</div>
                <div className="space-y-1 mb-2">
                  {(subcats[c.id] || []).map((s) => (
                    <div key={s.id} className="flex items-center justify-between bg-white rounded px-2 py-1 text-sm border border-stone-100">
                      <span>{s.name}</span>
                      <button onClick={() => removeSub(c.id, s.id)} className="text-stone-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  ))}
                  {(subcats[c.id] || []).length === 0 && <div className="text-xs text-stone-400">Sin subcategorías</div>}
                </div>
                <div className="flex gap-2">
                  <Input placeholder="Nueva subcategoría" value={subForm[c.id] || ""} onChange={(e) => setSubForm({ ...subForm, [c.id]: e.target.value })} className="h-8 text-sm" onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addSub(c.id); } }} />
                  <Button size="sm" onClick={() => addSub(c.id)}><Plus className="w-4 h-4" /></Button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}