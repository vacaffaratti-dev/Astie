import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useSession } from "@/lib/session";
import { useCart } from "@/lib/cart";
import { getProduct } from "@/lib/productService";
import { getCategories } from "@/lib/categoryService";
import { Button } from "@/components/ui/button";
import { Image as ImageIcon, ArrowLeft, ShoppingCart, Minus, Plus } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { session } = useSession();
  const { addItem } = useCart();
  const [product, setProduct] = useState(null);
  const [categories, setCategories] = useState([]);
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session || session.role !== "customer") { navigate("/register"); return; }
    (async () => {
      try {
        const [p, cats] = await Promise.all([getProduct(id), getCategories()]);
        setProduct(p);
        setCategories(cats);
      } finally {
        setLoading(false);
      }
    })();
  }, [id, session, navigate]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-8 h-8 border-4 border-stone-200 border-t-emerald-600 rounded-full animate-spin" /></div>;
  if (!product) return <div className="p-10 text-center text-stone-500">Producto no encontrado.</div>;

  const cat = categories.find((c) => c.id === product.category_id);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <Link to="/catalog" className="inline-flex items-center text-sm text-stone-500 hover:text-stone-900 mb-4">
        <ArrowLeft className="w-4 h-4 mr-1" /> Volver al catálogo
      </Link>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="aspect-square bg-stone-50 rounded-[24px] overflow-hidden border border-stone-200 shadow-sm">
          {product.image_url ? (
            <Image src={product.image_url} alt={product.name} fittingType="fill" className="w-full h-full" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-stone-300"><ImageIcon className="w-16 h-16" /></div>
          )}
        </div>
        <div className="flex flex-col">
          {cat && <span className="text-xs uppercase tracking-widest text-emerald-700 font-medium">{cat.name}</span>}
          <h1 className="font-display text-2xl sm:text-3xl font-semibold mt-1">{product.name}</h1>
          <p className="text-stone-600 mt-4 leading-relaxed">{product.description || "Sin descripción"}</p>
          <div className="mt-6">
            <span className={`inline-flex items-center gap-1.5 text-sm ${product.stock > 0 ? "text-emerald-600" : "text-red-500"}`}>
              <span className={`w-2 h-2 rounded-full ${product.stock > 0 ? "bg-emerald-500" : "bg-red-500"}`} />
              {product.stock > 0 ? `${product.stock} unidades disponibles` : "Sin stock"}
            </span>
          </div>
          <div className="mt-6 flex items-center gap-3">
            <div className="flex items-center border border-stone-200 rounded-lg">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-2 hover:bg-stone-100 rounded-l-lg"><Minus className="w-4 h-4" /></button>
              <span className="w-10 text-center text-sm font-medium">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="p-2 hover:bg-stone-100 rounded-r-lg"><Plus className="w-4 h-4" /></button>
            </div>
            <Button className="flex-1 bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm shadow-emerald-900/10" onClick={() => { addItem(product, qty); navigate("/cart"); }}>
              <ShoppingCart className="w-4 h-4 mr-2" /> Agregar al carrito
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}