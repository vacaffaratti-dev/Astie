// Bus de eventos interno + servidor WebSocket para push en tiempo real.
//
// Clientes se conectan a   ws://<host>/ws   y DEBEN autenticarse primero (los navegadores no pueden
// mandar headers en un WebSocket, así que las credenciales van en el primer mensaje).
//
// Protocolo (JSON):
//   Cliente → servidor:   { type: "auth", role, token?, id? }           (obligatorio, primero)
//                         { type: "subscribe", entity: "Message", quoteId?: "abc" }
//                         { type: "unsubscribe", entity, quoteId? }
//                         { type: "ping" }
//   Servidor → cliente:   { type: "auth_ok", role }
//                         { type: "event",  entity: "Message", event: { id, type, data } }
//                         { type: "pong" } · { type: "ping" }
//                         { type: "error", message, code? }
//
// Sin autenticación válida el servidor cierra la conexión con el código 4401.
//
// Cada cliente solo recibe eventos de entidades que su rol puede leer, y un cliente (comprador) solo
// los de sus propias cotizaciones y mensajes: mismas reglas que la API REST (ver access.js).

"use strict";

const { WebSocketServer, WebSocket } = require("ws");
const { authenticate } = require("./middleware/auth");
const { isEntity, roleCan, canRead } = require("./access");

// Tiempo máximo para autenticarse tras conectar (configurable solo para pruebas)
const AUTH_TIMEOUT_MS = Number(process.env.WS_AUTH_TIMEOUT_MS) || 10_000;

// ── Bus de eventos interno ────────────────────────────────────────────────────
// Usado por database.js para notificar cambios a todos los clientes WS.

const listeners = {};

function emit(entity, event) {
  (listeners[entity] || []).forEach((cb) => {
    try { cb(event); } catch { /* ignorar */ }
  });
}

function on(entity, cb) {
  (listeners[entity] ||= []).push(cb);
  return () => {
    listeners[entity] = (listeners[entity] || []).filter((f) => f !== cb);
  };
}

// ── Servidor WebSocket ─────────────────────────────────────────────────────────

let wss = null;

function attachToServer(httpServer) {
  wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws) => {
    // Cada cliente mantiene un mapa de cancelaciones: clave de suscripción → unsub()
    const subs = new Map();
    let astie = null; // identidad verificada; null hasta que llegue un "auth" válido

    const send = (obj) => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
    };
    const reject = (message) => {
      send({ type: "error", code: 401, message });
      ws.close(4401, "unauthorized");
    };

    const authTimer = setTimeout(() => { if (!astie) reject("Falta autenticación"); }, AUTH_TIMEOUT_MS);

    const handle = async (raw) => {
      let msg;
      try { msg = JSON.parse(raw); } catch {
        return send({ type: "error", message: "JSON inválido" });
      }
      if (!msg || typeof msg !== "object") return send({ type: "error", message: "Mensaje inválido" });

      if (msg.type === "ping") return send({ type: "pong" });
      if (msg.type === "pong") return; // respuesta al ping del servidor

      if (msg.type === "auth") {
        if (astie) return send({ type: "error", message: "Ya autenticado" });
        try {
          astie = await authenticate(msg.role, msg.token, msg.id);
        } catch (err) {
          return reject(err.message || "No autorizado");
        }
        clearTimeout(authTimer);
        return send({ type: "auth_ok", role: astie.role });
      }

      if (!astie) return reject("Autenticación requerida");

      if (msg.type === "subscribe") {
        const entity = msg.entity;
        if (!entity) return send({ type: "error", message: "Falta entity" });
        if (!isEntity(entity)) return send({ type: "error", message: `Entidad desconocida: ${entity}` });
        if (!roleCan(astie.role, entity, "read")) {
          return send({ type: "error", message: `Sin permiso para suscribirse a ${entity}` });
        }
        const quoteId = typeof msg.quoteId === "string" && msg.quoteId ? msg.quoteId : null;

        // Cancelar suscripción anterior para esta entity+quoteId
        const key = quoteId ? `${entity}:${quoteId}` : entity;
        if (subs.has(key)) subs.get(key)();

        const unsub = on(entity, (event) => {
          // Filtrar por quoteId si el cliente lo especificó
          if (quoteId && event.data?.quote_id !== quoteId) return;
          // Un cliente (comprador) solo recibe lo suyo
          if (!canRead(astie, entity, event.data)) return;
          send({ type: "event", entity, event });
        });
        subs.set(key, unsub);
        return;
      }

      if (msg.type === "unsubscribe") {
        const key = typeof msg.quoteId === "string" && msg.quoteId ? `${msg.entity}:${msg.quoteId}` : msg.entity;
        if (subs.has(key)) { subs.get(key)(); subs.delete(key); }
        return;
      }

      send({ type: "error", message: `Tipo desconocido: ${msg.type}` });
    };

    // Los mensajes se procesan de uno en uno: la autenticación es asíncrona (PBKDF2) y el cliente
    // manda "auth" y las suscripciones seguidas; así ninguna suscripción se adelanta al "auth".
    let queue = Promise.resolve();
    ws.on("message", (raw) => {
      queue = queue.then(() => handle(raw)).catch(() => { /* un mensaje malo no rompe la cola */ });
    });

    ws.on("close", () => {
      clearTimeout(authTimer);
      subs.forEach((unsub) => unsub());
      subs.clear();
    });

    ws.on("error", () => { /* el cierre se gestiona en "close" */ });

    // Enviar ping cada 30 s para mantener la conexión viva (útil en proxies/Capacitor)
    const heartbeat = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "ping" }));
      else clearInterval(heartbeat);
    }, 30_000);
    ws.on("close", () => clearInterval(heartbeat));
  });

  console.log("[ws] servidor WebSocket activo en /ws");
  return wss;
}

module.exports = { emit, on, attachToServer };
