package com.astie.diesel;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
