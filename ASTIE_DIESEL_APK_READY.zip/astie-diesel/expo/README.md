# ASTIE DIESEL en Expo Go

`App.js` abre la web de ASTIE DIESEL (la misma de `src/`) dentro de un WebView a pantalla completa, para probarla en el
celular con **Expo Go** sin generar un APK. No es una reescritura nativa: es la web dentro de un contenedor.

## Lo que necesitas

- Expo Go instalado en el celular (Play Store).
- Una PC con Node, en la **misma Wi-Fi** que el celular (Expo Go carga el proyecto desde ella).

## Paso 1 — Levantar la web y el servidor (en la PC)

En la carpeta del proyecto ASTIE:

```bash
npm run server:dev                 # terminal 1: backend en el puerto 3001
```

Antes del siguiente paso, crea/edita `.env` con la IP de tu PC en la red (no `localhost`: en el celular `localhost` es el propio celular):

```
VITE_API_URL=http://192.168.1.100:3001
```

```bash
npm run dev -- --host              # terminal 2: web en el puerto 5173 y visible desde la red
```

Vite muestra algo como `Network: http://192.168.1.100:5173/`. Esa es la dirección para la app.
Si el celular no conecta, permite los puertos 3001, 5173 y 8081 en el firewall de la PC.

## Paso 2 — Crear el proyecto Expo (una vez)

```bash
npx create-expo-app@latest astie-expo --template blank
cd astie-expo
npx expo install react-native-webview @react-native-async-storage/async-storage react-native-safe-area-context
```

Copia `App.js` de esta carpeta sobre el `App.js` del proyecto (si la plantilla creó `App.tsx`, bórralo).

## Paso 3 — Abrirlo

```bash
npx expo start
```

Escanea el QR con Expo Go. La primera vez la app pide la dirección de la web: escribe la de Vite
(`http://192.168.1.100:5173`). Queda guardada; si no carga, la pantalla de error permite reintentar o cambiarla.

## Con la web publicada (sin `--host`)

Publica la web en un hosting con HTTPS y usa esa dirección. Lo más simple es `npm run build:webview`, que genera una web que
funciona en cualquier hosting estático sin configurar redirecciones; el backend también debe estar en HTTPS
(`VITE_API_URL` en `.env.webview`).

## Notas

- **Expo Go es para probar**, no para repartir: quien la use necesita Expo Go y que tu PC esté encendida y en la red. Para un APK instalable con este mismo `App.js` se usa EAS Build (cuenta de Expo), o el kit de Capacitor del proyecto (`docs/ANDROID.md`).
- La versión de Expo Go debe coincidir con el SDK del proyecto: `create-expo-app@latest` crea el más reciente. Si Expo Go dice que la versión no es compatible, actualiza Expo Go o crea el proyecto con la versión que soporte.
- El botón «atrás» de Android retrocede dentro de la app; los enlaces `tel:`, `mailto:` y `whatsapp:` se abren con la app del sistema.
- Las sesiones y el carrito se guardan en el WebView y se conservan al cerrar Expo Go.
